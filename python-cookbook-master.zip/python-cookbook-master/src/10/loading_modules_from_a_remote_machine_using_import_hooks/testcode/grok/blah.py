print("I'm grok.blah")

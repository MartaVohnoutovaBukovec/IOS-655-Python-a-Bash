import sample
s = "Spicy Jalape\u00f1o"
sample.print_chars(s)
sample.print_wchars(s)

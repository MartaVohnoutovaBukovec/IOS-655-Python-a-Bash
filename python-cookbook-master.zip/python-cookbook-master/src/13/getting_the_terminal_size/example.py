import os
sz = os.get_terminal_size()
print(sz.columns, 'columns')
print(sz.lines, 'lines')
